package com.idiot.servlet;

public @interface webservlet {

}

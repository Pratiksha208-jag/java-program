package com.idiot.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServlet;
@webservlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final String query="insert into bookinfo(Bookname,bookedition,bookprice) VALUES(?,?,?)";
	@override
	protected void doGet(HttServlet req,HttpServletResponse res) throws servlet
	//get PrintWriter
	PrintWriter pw=res.getWriter();
	//set content type
	res.setContentType("text/html");
	//GET THE Bookdata
	String BookName=req.getParameter("bookname");
	String bookedition=req.getParameter("bookedition");
	float bookprice= Float.parseFloat(req.getParameter("bookprice"));
	
	//LOAD jdbc driver
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		}
	catch(ClassNotFoundException cnf) {
		cnf.fillInStackTrace();
	}
	//generate the connection
	try(Connection con=DriverManager.getConnection("jdbc:mysql:///BookInfo","root","root")
			PreparedStatement ps=con.prepareStatement(query);){
		ps.setString(1,bookname);
		ps.setString(2, bookedition);
		ps.setFloat(3,bookprice);
		int count=ps.executeUpdate();
		if(count==1) {
		pw.println("<h2>Record is Register successfully</h2>");
		} else {
			pw.println("<h2>Record is not Register</h2>")
	}catch(SQLException se) {
		se.printStackTrace();
		pw.println("<h1>"+se.getMessage()+"</h2>");
	}catch(SQLException e) {
		se.printStackTrace();
		pw.println("<h1>"+e.getMessage()+"</h2>");
		pw.println("<a href='home.html'>Home</a>");
	}pw.println("<br>")
	pw.println("<a href='booklist'>BookList</a>");
 @Override
 protected void doPost(HttpServletRequest req,HttpServletResponse res) throws Servlet
    doGet(req,res);
} 
      
}

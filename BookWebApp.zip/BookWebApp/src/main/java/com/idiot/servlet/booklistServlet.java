package com.idiot.servlet;

import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@webServlet("/booklist")
public class booklistServlet extends HttpServlet {
	private static final String query="SELECT ID,BOOKNAME,BOOKEDITION<BOOKPRICE FROM BookInfo";
	@override
	protected void doGet(HttServlet req,HttpServletResponse res) throws servlet
	//get PrintWriter
	PrintWriter pw=res.getWriter();
	//set content type
	res.setContentType("text/html");
	
	//LOAD jdbc driver
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		}
	catch(ClassNotFoundException cnf) {
		cnf.fillInStackTrace();
	}
	//generate the connection
	try(Connection con=DriverManager.getConnection("jdbc:mysql:///BookInfo","root","root")
			PreparedStatement ps=con.prepareStatement(query);){
		ResultSet rs=ps.executeQuery();
		pw.println("<table>");
		pw.println("<tr>");
		pw.println("<th> Book Id</th>");
		pw.println("<th> Book Name</th>");
		pw.println("<th> Book Edition</th>");
		pw.println("<th> Book Price</th>");
		pw.println("</tr>");
		while(rs.next()) {
			pw.println("<tr>");
			pw.println("<td>"+rs.getInt(1) "</th>");
			pw.println("<td>"+rs.getstring(2)"</th>");
			pw.println("<td>"+rs.getstring(3)"</th>");
			pw.println("<td>"+rs.getFloat "</th>");
			pw.println("</tr>");	
			pw.println("</table>");
			}catch(SQLException se) {
		se.printStackTrace();
		pw.println("<h1>"+se.getMessage()+"</h2>");
	}catch(SQLException e) {
		se.printStackTrace();
		pw.println("<h1>"+e.getMessage()+"</h2>");
	}
	pw.println("<a href='home.html'>Home</a>");
 @Override
 protected void doPost(HttpServletRequest req,HttpServletResponse res) throws Servlet
    doGet(req,res);
} 
      

}

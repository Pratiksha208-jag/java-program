package javax.servlet.http;

public class HttpServletResponse {

	public void setContentType(String string) {
		// TODO Auto-generated method stub
		
	}

}
